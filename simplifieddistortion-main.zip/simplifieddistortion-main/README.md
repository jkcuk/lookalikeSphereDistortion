# Simplified Distortion App

The program simulates motion status solely by altering the velocity components in the phone's coordinate system.

The initial camera resolution is set to 1280*720. If the camera's video stream aspect ratio is not 16:9, parameters need to be manually adjusted.
